//
//  PhotoViewController.swift
//  UnivCam
//
//  Created by BLU on 2017. 7. 15..
//  Copyright © 2017년 futr_blu. All rights reserved.
//

import UI

class PhotoVC: UIViewController {
    
    @IBOutlet var collectionView: UICollectionView! {
        didSet {
            collectionView.dataSource = photoDataSource
            collectionView.delegate = self
            collectionView.register(UINib(nibName: "PhotoCell", bundle: nil), forCellWithReuseIdentifier: "UICollectionViewCell")
        }
    }
    @IBOutlet var thumbnailCollectionView: UICollectionView! {
        didSet {
            thumbnailCollectionView.dataSource = photoDataSource
            thumbnailCollectionView.delegate = self
            thumbnailCollectionView.register(UINib(nibName: "PhotoCell", bundle: nil), forCellWithReuseIdentifier: "UICollectionViewCell")
        }
    }
    
    let photoDataSource = PhotoDataSource()
    var selectedIndex : IndexPath?
    var photos = [UIImage]()
    var _selectedCells : NSMutableArray = []
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        photoDataSource.photos.removeAll()
        photoDataSource.photos = photos
        
        guard let selectedIndex = selectedIndex else { return }
        
        collectionView.selectItem(at: selectedIndex,
                                  animated: false,
                                  scrollPosition: .centeredHorizontally)
        
        _selectedCells.add(selectedIndex)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let button : UIButton = .init(type : .system)
        button.setImage(Assets.leftNavigationItem.image, for: .normal)
        button.setTitle("  뒤로가기", for: .normal)
        button.sizeToFit()
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: button)
        
        button.addTarget(self, action: #selector(unwindToAlbum), for: .touchUpInside)
        
        // Do any additional setup after loading the view.
    }
    
    func unwindToAlbum() {
        //        if let vc = self.navigationController?.viewControllers[1] {
        //            self.navigationController?.popToViewController(vc, animated: true)
        //        }
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        
        
        if scrollView == collectionView {
            
            for indexPath in _selectedCells {
                guard let indexPath = indexPath as? IndexPath else { return }
                thumbnailCollectionView.cellForItem(at: indexPath)?.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                _selectedCells.remove(indexPath)
            }
            
            
            let index = targetContentOffset.pointee.x / view.frame.width
            
            let indexPath = IndexPath(item: Int(index), section: 0)
            thumbnailCollectionView.selectItem(at: indexPath, animated: true, scrollPosition: UICollectionViewScrollPosition())
            thumbnailCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
            thumbnailCollectionView.cellForItem(at: indexPath)?.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
            _selectedCells.add(indexPath)
            
        }
        print("움직이는중")
    }
    
    
}
extension PhotoVC : UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView == self.collectionView {
            let vc = UIStoryboard(name: "Search", bundle: nil).instantiateViewController(withIdentifier: "GallerySliderVC") as! GallerySliderVC
            vc.photos = photos
            
            self.present(vc,
                         animated: false,
                         completion: nil)
        } else if collectionView == self.thumbnailCollectionView {
           
            for indexPath in _selectedCells {
                guard let indexPath = indexPath as? IndexPath else { return }
                thumbnailCollectionView.cellForItem(at: indexPath)?.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                print(indexPath)
                _selectedCells.remove(indexPath)
            }
            
            self.collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
            collectionView.cellForItem(at: indexPath)?.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            _selectedCells.add(indexPath)
            
        }
    }
}

extension PhotoVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize{
        return collectionView == thumbnailCollectionView ? CGSize(width: 63, height: 63) : CGSize(width: self.view.frame.size.width, height: self.view.frame.size.height - 63)
    }
    
}
