//
//  PhotoCell.swift
//  UnivCam
//
//  Created by BLU on 2017. 8. 4..
//  Copyright © 2017년 futr_blu. All rights reserved.
//

import UIKit

class PhotoCell: UICollectionViewCell, UIScrollViewDelegate {

    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var imageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //scrollView.delegate = self
       
        //self.scrollView.minimumZoomScale = 1.0
        //self.scrollView.maximumZoomScale = 6.0
    }

    func viewForZoomInScrollView(scrollView: UIScrollView) -> UIView? {
        return self.imageView
    }
    func zoomImage(_ gesture: UIPinchGestureRecognizer) {
        if gesture.state == .ended || gesture.state == .changed {
            print("gesture.scale = \(gesture.scale)")
            let currentScale: CGFloat = frame.size.width / bounds.size.width
            var newScale: CGFloat = currentScale * gesture.scale
            if newScale < 1.0 {
                newScale = 1.0
            }
            if newScale > 6.0 {
                newScale = 1.0
            }
            let transform = CGAffineTransform(scaleX: newScale, y: newScale)
            imageView.transform = transform
            scrollView.contentSize = imageView.frame.size
        }
    }

    func setup() {
        
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(self.zoomImage))
        imageView.gestureRecognizers = [pinch]
        imageView.isUserInteractionEnabled = true
        scrollView.delegate = self
    }
}
