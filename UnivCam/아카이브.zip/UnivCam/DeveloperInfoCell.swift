//
//  DeveloperInfoCell.swift
//  UnivCam
//
//  Created by 이준상 on 2017. 8. 9..
//  Copyright © 2017년 futr_blu. All rights reserved.
//

import Foundation
import UIKit

class DeveloperInfoCell : UITableViewCell {
    
    @IBOutlet weak var leftLabel: UILabel!
    @IBOutlet weak var rightLabel: UILabel!
}
