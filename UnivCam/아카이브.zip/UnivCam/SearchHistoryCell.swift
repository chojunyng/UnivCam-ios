//
//  SearchHistoryCell.swift
//  UnivCam
//
//  Created by 이준상 on 2017. 8. 11..
//  Copyright © 2017년 futr_blu. All rights reserved.
//

import Foundation
import UIKit

class SearchHistoryCell : UITableViewCell {
    
    @IBOutlet var leftLabel : UILabel!
    @IBOutlet var rightLabel : UILabel!
}
