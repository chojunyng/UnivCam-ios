//
//  Photo.swift
//  UnivCam
//
//  Created by BLU on 2017. 8. 14..
//  Copyright © 2017년 futr_blu. All rights reserved.
//

import Foundation
import RealmSwift

class Photo: Object {
    
    dynamic var id = UUID().uuidString
    dynamic var title = ""
    dynamic var createdAt = NSDate()
    dynamic var url = ""
    //let Album = LinkingObjects(fromType: Album.self, property: "transactions")
    
//    static func incrementID() -> Int {
//        let realm = try! Realm()
//        return (realm.objects(Photo.self).max(ofProperty: "id") as Int? ?? 0) + 1
//    }
    override static func primaryKey() -> String? {
        return "id"
    }
}
