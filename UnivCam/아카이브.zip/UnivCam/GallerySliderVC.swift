//
//  GallerySliderVC.swift
//  UnivCam
//
//  Created by BLU on 2017. 8. 13..
//  Copyright © 2017년 futr_blu. All rights reserved.
//

import UIKit

class GallerySliderVC: UIViewController {
    
    @IBOutlet var collectionView: UICollectionView! {
        didSet {
            collectionView.dataSource = photoDataSource
            collectionView.delegate = self
            collectionView.register(UINib(nibName: "PhotoCell", bundle: nil), forCellWithReuseIdentifier: "UICollectionViewCell")
            //collectionView.setZoomScale(<#T##scale: CGFloat##CGFloat#>, animated: <#T##Bool#>)
            
        }
        
    }
    
    let photoDataSource = PhotoDataSource()
    var selectedIndex : IndexPath?
    var photos = [UIImage]()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        photoDataSource.setupFlag = true
        photoDataSource.photos.removeAll()
        photoDataSource.photos = photos
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissDidTap))
        collectionView.addGestureRecognizer(tapGesture)
        
        // Do any additional setup after loading the view.
    }
    func dismissDidTap() {
        self.dismiss(animated: false, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override var prefersStatusBarHidden: Bool {
        return true
    }
}

extension GallerySliderVC : UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
    }
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
    }
}
extension GallerySliderVC : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize{
        return CGSize(width: self.view.frame.size.width, height: self.view.frame.size.height - 63)
    }
    
}

