//
//  PhotoCollectionViewCell.swift
//  UnivCam
//
//  Created by BLU on 2017. 7. 14..
//  Copyright © 2017년 futr_blu. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageView: UIImageView!
    
}
