//
//  PhotoDataSource.swift
//  UnivCam
//
//  Created by BLU on 2017. 8. 4..
//  Copyright © 2017년 futr_blu. All rights reserved.
//

import UIKit

class PhotoDataSource: NSObject, UICollectionViewDataSource {
    
    var photos = [UIImage]()
    var setupFlag = false
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let identifier = "UICollectionViewCell"
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! PhotoCell
        let photo = photos[indexPath.row]
        cell.imageView.image = photo
        cell.setup()
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tap))
//        cell.scrollView.addGestureRecognizer(tapGesture)
        if setupFlag {
            cell.scrollView.isUserInteractionEnabled = true
        }
        if indexPath.row == 0 {
           cell.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }
        //cell.setup()
        //cell.scrollView.isUserInteractionEnabled = false
        //cell.backgroundColor = UIColor.brown
        //cell.backgroundColor = UIColor(patternImage: photo)
        
        return cell
    }
//    func tap() {
//        print("tapped")
//    }
//    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "CustomHeaderCell", for: indexPath as IndexPath)
//        return headerView
//    }
}
